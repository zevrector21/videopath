from django.dispatch import Signal

analytics_imported = Signal()
