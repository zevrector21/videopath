def invalidate(distribution_id, path):
	return True

def check_access():
	return True