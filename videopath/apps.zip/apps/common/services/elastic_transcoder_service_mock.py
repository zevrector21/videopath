
#
# Start a transcoding job
#
def start_transcoding_job(input, other, outputs):
	return "some id"

#
# Confirm SNS subscription
#
def confirm_subscription_topic(topic, token):
	return "some confirmation"

#
#
#
def check_connection():
	return True