
import os
service_path = os.path.dirname(os.path.realpath(__file__)) + "/geo_ip_service.py"
execfile(service_path)


