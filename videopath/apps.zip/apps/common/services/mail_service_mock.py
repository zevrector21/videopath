
def mandrill_send(message):
   pass

#
# Check acccess
#
def check_access():
	return True