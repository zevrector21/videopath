

def send_message(exchange, message):
	return True

def receive_messages(queue, handler):
	pass

def test_connection():
	return True
