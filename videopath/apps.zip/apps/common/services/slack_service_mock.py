

def notify(text):
	pass