from videopath.apps.common.test_utils import BaseTestCase

IMPORT_URL = '/v1/video/{0}/import_source/'

# Uses the standard django frame testing client
class TestCase(BaseTestCase):

    def test_thumbs(self):
    	
        pass
        # todo

