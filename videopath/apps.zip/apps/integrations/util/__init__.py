

def oauth_endpoint_for_user(service, user):
	return